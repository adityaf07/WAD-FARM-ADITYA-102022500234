<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title><?php echo e(isset($pelanggan) ? 'Edit' : 'Tambah'); ?> Data Pelanggan</title>
</head>
<body>
<div class="container" style="max-width: 600px;">
    <h1><?php echo e(isset($pelanggan) ? 'Edit' : 'Tambah'); ?> Data Pelanggan</h1>
    <div class="card-custom">

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST"
              action="<?php echo e(isset($pelanggan) ? route('pelanggan.update', $pelanggan->id_pelanggan) : route('pelanggan.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if(isset($pelanggan)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="mb-3">
                <label>Nama Lengkap</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama"
                       value="<?php echo e(old('nama', $pelanggan->nama ?? '')); ?>" required>
            </div>
            <div class="mb-3">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Masukkan alamat lengkap"
                       value="<?php echo e(old('alamat', $pelanggan->alamat ?? '')); ?>" required>
            </div>
            <div class="mb-3">
                <label>No. Telpon</label>
                <input type="text" name="notelp" class="form-control" placeholder="Contoh: 08123456789"
                       value="<?php echo e(old('notelp', $pelanggan->notelp ?? '')); ?>" required>
            </div>
            <div class="mb-4">
                <label>Catatan</label>
                <input type="text" name="catatan" class="form-control" placeholder="Tambahkan catatan (opsional)"
                       value="<?php echo e(old('catatan', $pelanggan->catatan ?? '')); ?>">
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100">
                    <?php echo e(isset($pelanggan) ? 'Update Data' : 'Simpan Data'); ?>

                </button>
                <a href="<?php echo e(route('pelanggan.index')); ?>" class="btn btn-secondary w-100">Batal</a>
            </div>
        </form>
    </div>
</div>
</body>
</html><?php /**PATH C:\laragon\www\coba\resources\views/pelanggan/form.blade.php ENDPATH**/ ?>