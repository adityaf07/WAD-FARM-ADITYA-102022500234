<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>Modul Data Pelanggan</title>
</head>
<body>
<div class="container">
    <h1>Data Pelanggan</h1>
    <div class="card-custom">
        <a href="<?php echo e(route('pelanggan.create')); ?>" class="btn btn-primary mb-4">+ Tambah Data</a>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>No.Telpon</th>
                        <th>Catatan</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($p->nama); ?></td>
                        <td><?php echo e($p->alamat); ?></td>
                        <td><?php echo e($p->notelp); ?></td>
                        <td><?php echo e($p->catatan); ?></td>
                        <td class="text-center">
                            <button type="button" class="btn btn-secondary text-light btn-sm"
                                data-bs-toggle="modal" data-bs-target="#detail<?php echo e($p->id_pelanggan); ?>">Detail</button>
                            <a href="<?php echo e(route('pelanggan.edit', $p->id_pelanggan)); ?>" class="btn btn-warning text-light btn-sm">Edit</a>
                            <form action="<?php echo e(route('pelanggan.destroy', $p->id_pelanggan)); ?>" method="POST" class="d-inline"
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>

                    
                    <div class="modal fade" id="detail<?php echo e($p->id_pelanggan); ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Detail Pelanggan</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong>Nama:</strong> <?php echo e($p->nama); ?></p>
                                    <p><strong>Alamat:</strong> <?php echo e($p->alamat); ?></p>
                                    <p><strong>No. Telpon:</strong> <?php echo e($p->notelp); ?></p>
                                    <p><strong>Catatan:</strong> <?php echo e($p->catatan); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\laragon\www\coba\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>